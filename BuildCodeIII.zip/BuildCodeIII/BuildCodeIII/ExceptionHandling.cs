﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Linq.Expressions;
//using System.Numerics;
//using System.Text;
//using System.Threading.Tasks;

//namespace BuildCodeIII
//{
//    class ExceptionHandling
//    {
//        public int NotANumber(int _input)
//        {
//            if billTotal(_input) = string;
//            {

//            }
//        }

//        public int EnteredZero(int _input)
//        {
//            int _input = 0;
//            try
//            {
//                _input = 0;
//                Console.WriteLine(_input);
//            }
//            catch (EnteredZeroException)
//            {
//                Console.WriteLine("0 is not a valid input.");
//                ReadLine();
//                GetBillTotal();
//            }
//        }

//    }
//}
