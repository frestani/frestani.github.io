﻿// Originally built by Programming 101 Professors
// Received tutoring help from Grace Anders
// Did not do in-class with peers; used example code

// Wasn't sure how to break this down into a more condensed version, as everything works well

using System;
using static System.Console;

namespace TipCalculator
{
    class Program
    {
        static void Main()
        {
            Calculate c = new Calculate();
        }
    }

    class Calculate
    {
        double billTotal;
        public Calculate()
        {
            Title = "Tip Calculator";
            GetBillTotal();
        }

        private void GetBillTotal()
        {
            Clear();
            WriteLine("What was the total of your bill?");
            string input = ReadLine();
            try
            {
                // Explicit Conversion
                billTotal = Convert.ToDouble(input);
            }
            catch(System.FormatException)
            {
                WriteLine("You need to enter a number.");
                ReadKey();
                GetBillTotal();
            }
            GetTipAmount(billTotal);
        }
        private void GetTipAmount(double billTotal)
        {
            Clear();
            WriteLine("What do you want to tip?");
            WriteLine("1) 15%");
            WriteLine("2) 20%");
            WriteLine("3) 75%");
            string input = ReadLine();

            int choice = Convert.ToInt32(input);

            switch (choice)
            {
                case 1:
                    Tip(billTotal, .15);
                    break;
                case 2:
                    Tip(billTotal, .20);
                    break;
                case 3:
                    Tip(billTotal, .75);
                    break;
            }
        }

        private void Tip(double billTotal, double tipPercentage)
        {
            double tipAmount = billTotal * tipPercentage;
            double finalAmount = billTotal + tipAmount;
            DisplayTip(tipAmount, finalAmount);
        }

        private void DisplayTip(double tip, double finalAmount)
        {
            Clear();
            //next week we'll learn how to format currency
            WriteLine("Tip $" + tip);
            WriteLine("Bill plus tip is: $" + finalAmount);

            WriteLine("\nPress enter to continue...");
            ReadLine();
            GetBillTotal();
        }

    }
}
