﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace PetHotel
{
    public class Pet
    {
        public string petName;
        string petType;
        int hungerLevel = 5;
        int thirstLevel = 5;
        public int happinessLevel = 0;

        public Pet(string name, string type)
        {
            petName = name;
            petType = type;
        }
        public void petInfo()
        {
            WriteLine("Pet name: " + petName);
            WriteLine("Pet type: " + petType);
            WriteLine("Hunger level: " + hungerLevel);
            WriteLine("Thirst level: " + thirstLevel);
            WriteLine("Happiness level: " + happinessLevel);
        }
    }
}
