﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetHotel
{
    internal class Activities
    {
        public string WalkPet(Pet P)
        {
            P.happinessLevel++;
            return $"You walked {P.petName}. \n {P.petName}'s happiness level: " + P.happinessLevel;
        }
        public string FeedPet(Pet P)
        {
            P.happinessLevel++;
            return $"You fed {P.petName}. \n {P.petName}'s happiness level: " + P.happinessLevel;
        }
        public string WaterPet(Pet P)
        {
            P.happinessLevel++;
            return $"You gave water to {P.petName}. \n {P.petName}'s happiness level: " + P.happinessLevel;
        }
        public string PlayWithPet(Pet P)
        {
            P.happinessLevel++;
            return $"You played with {P.petName}. \n {P.petName}'s happiness level: " + P.happinessLevel;
        }
        public string GroomPet(Pet P)
        {
            P.happinessLevel++;
            return $"You groomed {P.petName}. \n {P.petName}'s happiness level: " + P.happinessLevel;
        }
    }
}
