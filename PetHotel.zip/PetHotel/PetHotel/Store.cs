﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

// Store credit: In-class assignment (Emre Biberoglu)
// Store credit: Mack Pearson-Muggli

namespace PetHotel
{
    public class Store
    {
        //Properties
        public string Name { get; set; }
        public double Price { get; private set; }
        public List<Item> Items { get; set; }

        public void StoreSetup()
        {
            Greeting();
            Stock();
        }
        public void Stock()
        {
            Items = new List<Item>();

            Item dogFood = new Item();
            
                dogFood.Name = "Dog food";
                dogFood.Price = 4.00;
                
            Items.Add(dogFood);

            Item catFood = new Item();
            
                catFood.Name = "Cat food";
                catFood.Price = 4.00;
            Items.Add(catFood);

            Item smallDogToy = new Item();
            
                smallDogToy.Name = "Small dog toy";
                smallDogToy.Price = 2.00;
            Items.Add(smallDogToy);

            Item smallCatToy = new Item();
            
                smallCatToy.Name = "Small cat toy";
                smallCatToy.Price = 2.00;
            Items.Add(smallCatToy);
        }

        // GoToStore lists items available for purchase. Credit: Mack Pearson-Muggli
        public void GoToStore()
        {
            Console.WriteLine(Items.Count);
            int buy = 1;
            foreach (Item item in Items)
            {
                Console.WriteLine($"{buy}. {item.Name} ${item.Price}");
                buy++;
            }
        }

        public void Greeting()
        {
            Console.WriteLine("Welcome to the pet store!");
        }
    }
}
