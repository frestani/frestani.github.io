﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace PetHotel
{
    class Player
    {
        // Lists for Pets. Credit: Ciarren Hollis
        public string Name;
        public List<Pet> Pets;
        public double Wallet = 50.00;
        public List<Item> Inventory;

        public Player()
        {
            // Create a new list for pets and store items
            Pets = new List<Pet>();
            Inventory = new List<Item>();
        }
        // Store Inventory. Credit: Mack Pearson-Muggli
        public void ShowInventory()
        {
            foreach (Item item in Inventory)
            {
                int buy = 1;
                Console.WriteLine($"{buy}. {item.Name} ${item.Price}");
                buy++;
            }
        }
    }
}
