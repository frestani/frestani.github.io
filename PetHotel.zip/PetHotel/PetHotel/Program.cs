﻿// Pet Hotel by Francesca Restani
// Code credit: in-class code

/*
 * Pet Hotel Game
 * Francesca Restani
 * 11/8/2022
 */

using System;

namespace PetHotel
{
    class Program
    {
        static void Main(string[] args)
        {
            // Start a new game
            Game game = new Game("Pet Hotel");
            game.Start();
        }
    }
}
