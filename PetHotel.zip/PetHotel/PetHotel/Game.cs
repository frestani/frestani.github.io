﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace PetHotel
{
    class Game
    {
        string[] nameCatalogue = { "Piper", "Harry", "Millie", "LuLu", "Bailey", "Taco", "Samantha" };
        string[] animal = { "Dog", "Cat" };
        string[] activities = {"Walk Pet", "Feed Pet", "Water Pet", "Play with Pet", "Groom Pet" /*"Go to Store"*/};
        string playerStoreChoice;

        // Creating lists for pets and activities. Credit: Ciarren Hollis 
        Pet P;
        Activities A;

        int activitiesCompleted = 0;
        int maxActivities = 5;
        int totalHappinessCount = 0;

        Random random = new Random();

        public Pet CreateRandomPet()
        {
            string petName = nameCatalogue[random.Next(nameCatalogue.Length)];
            string petType = animal[random.Next(animal.Length)];
            P = new Pet(petName, petType);
            return P;
        }
        Player player;
        string GameTitle = "Pet Hotel";

        public Game(string title)
        {
            GameTitle = title;
            player = new Player();
        }
        int day;

        Store store = new Store();
        public void PlayerName()
        {
            //Get player's name, save it to instance of player
            WriteLine("Welcome to Pet Hotel!");
            WriteLine("Please enter your name:");
            player.Name = GetStringInput();
        }
        
        public void Start()
        {
            Title = GameTitle;
            A = new Activities();

           PlayerName();

           RunDay();
           
        }

        // RunDay() generates days - Grace Anders, Sebastian Pedersen
        public void RunDay()
        {
            StartDay();
            Activities();
            ReadKey();
        }

        public void PressEnter(string text)
        {
            WriteLine(text);
            ReadKey();
        }
        void CheckWin()
        {
            if (totalHappinessCount >= 20)
            {
                WriteLine("Congrats! You win!");
                ReadKey();
            }
        }

        public void StartDay()
        {
            CheckWin();
            day++;
            WriteLine("Today is day number " + day);
            WriteLine("Total happiness count: " + totalHappinessCount);
            player.Pets.Add(CreateRandomPet());
            player.Pets[day - 1].petInfo();
        }
        void Activities()
        {
            Pet P = player.Pets[day - 1];
            WriteLine("What would you like to do? (enter the number of the activity)");
            for (int i = 0; i < activities.Length; i++)
            {
                WriteLine("#" + (i + 1) + ": " + activities[i]);
            }
            //int input = int.Parse(ReadLine());

            int input = GetIntInput();

            switch (input)
            {
                case 1:
                    WriteLine(A.WalkPet(P));
                    break;
                case 2:
                    WriteLine(A.FeedPet(P));
                    break;
                case 3:
                    WriteLine(A.WaterPet(P));
                    break;
                case 4:
                    WriteLine(A.PlayWithPet(P));
                    break;
                case 5:
                    WriteLine(A.GroomPet(P));
                    break;
                //default: WriteLine("Invalid input");
                //    break;

                    //case 6:
                    //    store.StoreSetup();
                    //    store.GoToStore();
                    //    StorePurchase();
                    //    break;
            }
            activitiesCompleted++;

            WriteLine("You have completed " + activitiesCompleted + " activities today.");
            if (activitiesCompleted >= maxActivities)
            {
                totalHappinessCount += player.Pets[day-1].happinessLevel;
                
                PressEnter("Press Enter to start new day...");
                activitiesCompleted = 0;
                Clear();
                RunDay();
            }
            else
            {
                Activities();
            }
        }

        // Credit: Alex Gartner
        string GetStringInput()
        {
            string input = Console.ReadLine();
            bool numfound = false;

            foreach(char c in input)
            {
                if(Char.IsDigit(c))
                {
                    numfound = true;
                }
            }

            if(numfound)
            {
                Console.WriteLine("Number found. Please enter characters.");
                GetStringInput();
                return "";
            }
            else
            {
                return input;
            }
        }

        int GetIntInput()
        {
            string input = Console.ReadLine();

            int _num = 0;
            bool parsed = int.TryParse(input, out _num);
            if (parsed)
            {
                return _num;
            }
            else
            {
                Console.WriteLine("Not a valid input.");
                GetIntInput();
                return 0;
            }
        }

        void StorePurchase()
        {
            WriteLine("What would you like to buy?");
            WriteLine($"You have {player.Wallet}");
            playerStoreChoice = ReadLine();
            playerStoreChoiceInt = Convert.ToInt32(playerStoreChoice);
            ItemChosen = store.Items[playerStoreChoiceInt - 1];
            if (ItemChosen.Price <= player.Wallet)
            {
                player.Wallet = player.Wallet - ItemChosen.Price;
                player.Inventory.Add(ItemChosen);
                WriteLine($"You have purchased {ItemChosen.Name}");
                player.ShowInventory();
            }
            else if (ItemChosen.Price > player.Wallet)
            {
                WriteLine("You don't have enough money to buy this item.");
            }
        }
        public int playerStoreChoiceInt;
        public Item ItemChosen = new Item();
    }
}
