﻿using System;

namespace SubstitutionCipherFall2022
{
    internal class Cipher
    {

        //emre
        //4 12 17 4
        string Alphabet = "abcdefghijklmnopqrstuvwxyz 123456789";
        //f y j f
        string Substitute = "opdefghiqrsxyz123456789abcjklmntuvw ";

        //Greeting
        public void Greeting()
        {
            Console.WriteLine("Welcome to the cipher projet!");
            Console.WriteLine("Do you want to encode or decode a message? A) encode, B) decode C) quit");

            string UserInput = Console.ReadLine();
            UserInput.ToUpper();
            if (UserInput.ToUpper() == "A")
            {
                Encode();

            }
            else if (UserInput.ToUpper() == "B")
            {
                Decode();
            }
            else if (UserInput.ToUpper() == "C")
            {
                Environment.Exit(0);
            }
            else
            {
                Greeting();
            }

            Greeting();

        }
        public void Encode()
        {
            char[] AlphabetAsArray = Alphabet.ToCharArray();
            char[] SubstituteAsArray = Substitute.ToCharArray();

            Console.WriteLine("Type your message.");

            string message = Console.ReadLine();
            char[] messageAsArray = message.ToCharArray();

            string result = String.Empty;
            for (int i = 0; i < messageAsArray.Length; i++)
            {
                int index = Array.IndexOf(AlphabetAsArray, messageAsArray[i]);
                string replaceChar = SubstituteAsArray[index].ToString();
                //Console.WriteLine($"{messageAsArray[i]} {index} {replaceChar}");
                result += replaceChar;
            }

            Console.WriteLine($"Your encoded message is: {result}");

        }
        public void Decode()
        {
            char[] AlphabetAsArray = Alphabet.ToCharArray();
            char[] SubstituteAsArray = Substitute.ToCharArray();

            Console.WriteLine("Type your message.");

            string message = Console.ReadLine();
            char[] messageAsArray = message.ToCharArray();

            string result = String.Empty;
            for (int i = 0; i < messageAsArray.Length; i++)
            {
                int index = Array.IndexOf(SubstituteAsArray, messageAsArray[i]);
                string replaceChar = AlphabetAsArray[index].ToString();
                //Console.WriteLine($"{messageAsArray[i]} {index} {replaceChar}");
                result += replaceChar;
            }

            Console.WriteLine($"Your decoded message is: {result}");
        }
    }

}