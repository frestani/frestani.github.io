﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_201_Breakout1
{
    internal class Utility
    {
        public static void Print(string message)
        {
            Console.WriteLine(message);
        }

        public string ConvertToLower(string message)
        {
            return message.ToLower();
        }
        //alternative
        //public string ConvertToLower(string message) => message.ToLower();

        public int ConvertToInt(string input)
        {
            return Convert.ToInt32(input);
        }
    }
}
