﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace PROG_201_Breakout1
{
    public class Player
    {
        string name = "Fred";

        public List<Item> Inventory = new List<Item>();
        

        public string Name { get => name; set => name = value; }
        public Player(string _name)
        {
            //underscore = passed in
            name = _name;
        }
        public Player()
        {

        }

        public void setPlayerName(string _name)
        {
            name = _name;
        }

        //search for item by name
        public bool SearchCollectionByName(string itemName)
        {
            foreach (Item i in Inventory)
            {
                if (i.Name == itemName)
                {
                    return true;
                }
            }
            return false;
        }

        //add by name
        public void AddToCollectionByName(Item name)
        {
            Inventory.Add(name);
        }

        //remove by name
        public void RemoveFromCollectionByName(Item name)
        {
            Inventory.Remove(name);
        }

        public string ShowInventory()
        {
            string output = "";
            foreach (Item i in Inventory)
                output += i.Name + Environment.NewLine;
            return output;
        }
        public string ShowInventory(bool numbered)
        {
            string output = "";
            int number = 1;
            foreach (Item i in Inventory)
            {
                output += number + ":" + i.Name + Environment.NewLine;
                number++;
            }
                
            return output;
        }
    }

}
