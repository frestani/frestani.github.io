﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PROG_201_Breakout1
{
    public class Item
    {
        private string name;
        private int amount;

        public int Amount { get => amount; set => amount = value; }
        public string Name { get => name; set => name = value; }
    }
}