﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PROG_201_Breakout1
{
    public class CraftingTable
    {
        public CraftingTable()
        {

        }

        public Item Craft(Recipe recipe)
        {
            //code
            return new Item();
        }

        //example of return with no rturn type:
        public void About()
        {
            return;
        }
    }
}