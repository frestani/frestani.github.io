﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    static class Game
    {
        //declare variables
        //method with statements
    }
    class Program
    {
        static void Main()
        //our statements are here now
    }
}
