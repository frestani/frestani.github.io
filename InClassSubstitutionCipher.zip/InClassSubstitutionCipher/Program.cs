﻿using System;

namespace InClassSubstitutionCipher
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cipher cipher = new Cipher();
            //Greet user with information
            cipher.Greeting();
            //Show user two options: encode and decode

            //User chooses whether they want to encode or decode
            //User chooses encode
            //Ask user what they want to encode
            //Read what user wrote (input)
            //Create string for alphabet
            //Create string for substitute alphabet
            //Replace alphabet letters with substitute
            //Display cipher
            //User chooses decode
            //Make decoder - reverse process of encode

        }
    }
}
