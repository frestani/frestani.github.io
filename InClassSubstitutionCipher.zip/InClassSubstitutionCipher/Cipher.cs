﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InClassSubstitutionCipher
{
    internal class Cipher
    {
        string Alphabet = "abcdefghijklmnopqrstuvwxyz";
        string Substitute = "opdefghiqrsxyzabcjklmntuvw";

        //Greeting
        public void Greeting()
        {
            Console.WriteLine("Welcome to the cipher projet!");
            Console.WriteLine("Do you want to encode or decode a message? A) encode, B) decode");

            string UserInput = Console.ReadLine();
            UserInput.ToUpper();
            if (UserInput.ToUpper() == "A")
            {
                Encode();

            }
            else if (UserInput.ToUpper() == "B")
            {
                Decode();
            }
            else
            {
                Greeting();
            }

        }
        public void Encode()
        {
            char[] AlphabetAsArray = Alphabet.ToCharArray();
            char[] SubstituteAsArray = Substitute.ToCharArray();

            Console.WriteLine("Type your message.");

            string message = Console.ReadLine();
            char[] messageAsArray = message.ToCharArray();
            for (int i = 0; i <  messageAsArray.Length; i++)
            {
                Console.WriteLine(messageAsArray[i]);
            }
 
        }
        public void Decode()
        {
            char[] AlphabetAsArray = Alphabet.ToCharArray();
            char[] SubstituteAsArray = Substitute.ToCharArray();

            Console.WriteLine("Type your message.");
            string message = Console.ReadLine();
        }
    }
}
